run the server with command :
python server3.py

the server will run at localhost and listen at port 8765