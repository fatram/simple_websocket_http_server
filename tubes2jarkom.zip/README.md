# Simple Websocket Server
### Kelompok: Gaskeun
### Petunjuk Penggunaan Program
Buka terminal di file directory server
Jalankan server dengan perintah 
`python server3.py`
Server akan dijalankan di localhost dengan port 8765

### Pembagian tugas
|NIM|Nama| Apa yang dikerjakan | Persentase Kontribusi
|--|--| --| --|
|13515101|M. Ali Rido|eksploras protocol|33%
|13517044|Ignatius Timothy Manullang|Pair programming websocket|33%
|13517056|Fatur Rahman|Pair programming websocket|33%
